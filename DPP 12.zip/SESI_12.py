import cek_uppercase

text = input("masukan text :")
print("Banyaknya text uppercase adalah",cek_uppercase.cek_uppercase(text))
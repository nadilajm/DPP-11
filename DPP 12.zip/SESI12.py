from cek_uppercase import cek_uppercase

# text = input("masukan text :")
text = """While students read, monitor their discussion of text and reasoning. Provide students with corrective feedback if they misunderstand the text structure or do not recognize a signal word. If some students finish reading while others are still reading, prompt students who have finished to review the cue sheet and confirm the text structure based on their reasoning. After partners are finished reading the passage, allow pairs to share the story elements and the location in the text to support their statements. """

print("Banyaknya text uppercase adalah",cek_uppercase(text))
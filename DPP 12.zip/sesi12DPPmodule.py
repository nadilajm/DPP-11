def cek_uppercase(cek):
    banyaknya_upper = 0
    for i in cek:
        if i.isupper():
            banyaknya_upper += 1
    return banyaknya_upper